/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author User
 */
public class Remain {
    public static void main(String[] args) throws SQLException
    {
        Connection con=null;
        Statement stat=null;
        ResultSet res=null;
       
       // String user="remain";
        //String pass="1234";
        try
        {
            con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/reminder","root","");
            stat=(Statement) con.createStatement();
            res=stat.executeQuery("select * from remainde_tb");
            while(res.next())
            {
                System.out.println(res.getString("id")+","+res.getString("name")+","+res.getString("date"));
            }
        }catch(Exception exc)
        {
            exc.printStackTrace();
            
        }finally{
            if(res !=null){
                res.close();
            }
             if(stat !=null){
            stat.close();
        }   
             if(con !=null){
                 con.close();
             }
        }
        
    }
    
}
